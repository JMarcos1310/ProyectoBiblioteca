<div class="col-xs-12">
    <h1>Lista de Usuarios</h1>
    <?php if(!empty($this->session->flashdata())): ?>
		<div class="alert alert-<?php echo $this->session->flashdata('clase')?>">
			<?php echo $this->session->flashdata('mensaje') ?>
		</div>
	<?php endif; ?>
    <div>
        <a class="btn btn-success" href="<?php echo base_url() ?>index.php/datoscontrollers/agregar">Nuevo <i class="fa fa-plus"></i></a>
    </div>
    <br>
    <table border="2" class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Telefono</th>
                <th>Apellidos</th>
                <th>Editar</th>
                <th>Eliminar</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($usuarios as $datos){ ?>
            <tr>
                <td><?php echo $datos->idusario ?></td>
                <td><?php echo $datos->nombre ?></td>
                <td><?php echo $datos->telefono ?></td>
                <td><?php echo $datos->apellido ?></td>
                <td><a href="<?php echo base_url() ."index.php/datoscontrollers/editar/" . $datos->idusuario ?>">Hola</a></td>
                <td><a class="btn btn-success" href="<?php echo base_url() ."index.php/datoscontrollers/eliminar/" . $datos->idusario ?>"><i class="fa fa-trash"></i></a></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>