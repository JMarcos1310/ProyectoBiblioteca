<div class="col-xs-12">
	<h1>Alta de Usuarios</h1>
	<?php if(!empty($this->session->flashdata())): ?>
		<div class="alert alert-<?php echo $this->session->flashdata('clase')?>">
			<?php echo $this->session->flashdata('mensaje') ?>
		</div>
	<?php endif; ?>
	<form method="post" action="<?php echo base_url() ?>index.php/DatosControllers/guardar">
		<label for="nombre">Nombre:</label>
		<input class="form-control" name="nombre" required type="text" id="nombre" 
		placeholder="Escribe el nombre del usuario">

		<label for="telefono">Telefono:</label>
		<input class="form-control" name="telefono" required type="text" id="telefono" 
		placeholder="Escribe el telefono">

		<label for="apellido">Apellido:</label>
		<input class="form-control" name="apellido" required type="text" id="apellido" 
		placeholder="Escribe el apellido">

		
		<br><br><input class="btn btn-info" type="submit" value="Guardar">
	</form>
</div>