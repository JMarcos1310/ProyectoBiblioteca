<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class DatosModel extends CI_Model
{
    //Declaracion de variables publicas en base a las variables de mi tabla (usuarios) sql
    public $nombre;
    public $telefono;
    public $apellido;
    //Se carga por default
    public function __construct()
    {
        //Se carga la base de datos del archivo database.php
        $this->load->database();
    }
    //Inserta un registro a la tabla "usuario" de la base
    public function registro($nombre, $telefono, $apellido)
    {
        $this->nombre = $nombre;
        $this->telefono = $telefono;
        $this->apellido = $apellido;
        return $this->db->insert('usuarios', $this);
    }
    //ver con el Select * from de la tabla "usuarios" 
    public function todos(){
        return $this->db->get("usuarios")->result();
    }
    //delete de un registro de la tabla usuarios; se elimina por idusuario
    public function eliminar($idusuario){
        return $this->db->delete("usuarios", array("idusuario" => $idusuario));
    }
}   
?>