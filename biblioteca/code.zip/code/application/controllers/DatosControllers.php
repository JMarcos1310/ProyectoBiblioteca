<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DatosControllers extends CI_Controller {
   //Se carga por default la funcion construc
    public function __construct()
    {
        parent::__construct();
            //carga la clase datosmodel del CI_Model
            $this->load->model("DatosModel");
            //carga un destroy de una sesion
            $this->load->library('session');       
    }
    //carga el index por defualt
    public function index()
    {
        $this->load->view("datosusuarios/listar", array(
            "usuarios" => $this->DatosModel->todos()));
    }
	
    public function agregar(){
        $this->load->view("datosusuarios/agregar");
    }

    public function guardar(){
        $resultado = $this->DatosModel->registro(
                $this->input->post("nombre"),
                $this->input->post("telefono"),
                $this->input->post("apellido"),
            );
        if($resultado){
            $mensaje = "Registro guardado correctamente";
            $clase = "success";
        }else{
            $mensaje = "Error al guardar el registro";
            $clase = "danger";
        }
        $this->session->set_flashdata(array(
            "mensaje" => $mensaje,
            "clase" => $clase,
        ));
        redirect("DatosControllers/agregar");
    }

    public function editar(){

    }
    
    public function eliminar($idusuario){
        $resultado = $this->ProductoModel->eliminar($idusuario);
        if($resultado){
            $mensaje = "Producto eliminado correctamente";
            $clase = "success";
        }
        else
        {
            $mensaje = "Error al eliminar el producto";
            $clase = "danger";
        }
        $this->session->set_flashdata(array(
            "mensaje" => $mensaje,
            "clase" => $clase,));
            redirect("productos/");
        }
    

}
?>